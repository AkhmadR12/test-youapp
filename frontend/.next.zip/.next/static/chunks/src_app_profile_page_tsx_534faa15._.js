(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_profile_page_tsx_534faa15._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_profile_page_tsx_534faa15._.js",
  "chunks": [
    "static/chunks/_2bcdeea8._.js"
  ],
  "source": "dynamic"
});
