(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_profile_edit-about_page_tsx_534faa15._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_profile_edit-about_page_tsx_534faa15._.js",
  "chunks": [
    "static/chunks/node_modules_b85669fa._.js",
    "static/chunks/src_app_profile_edit-about_page_tsx_bdda8e6b._.js"
  ],
  "source": "dynamic"
});
